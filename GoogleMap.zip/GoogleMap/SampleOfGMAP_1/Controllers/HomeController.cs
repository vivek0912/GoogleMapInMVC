﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SampleOfGMAP_1.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Locations()
        {
            return View();
        }
        public ActionResult AutoLocationSearch()
        {
            return View();
        }
        public ActionResult AutoLocationSearch2()
        {
            return View();
        }
        public ActionResult AutoLocationSearch3()
        {
            return View();
        }
    }
}